package com.jdbc.spring.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Calendar;

@Repository
public class UserRepository {

	@Autowired
	JdbcTemplate jdbcTemplate;


	public String test() {

		return "Learning springboot jdbcTemplate to connect MySQL database.";
	}


	public String insertRecord() {
		Calendar calendar = Calendar.getInstance();
		java.util.Date currentTime = calendar.getTime();
		long time = currentTime.getTime();
		Timestamp current_time = new Timestamp(time);

		Timestamp updated_time = new Timestamp(time);
		System.out.println(updated_time.toString());
		String update, create = updated_time.toString();
		String insertSql = "insert into active_users(id,subject,initial_name,last_name,email,created_timestamp,updated_timestamp) values ('1','math','s','kl','ka@gmail.com', '" + current_time + "', '" + updated_time + "')";

		jdbcTemplate.execute(insertSql);

		insertSql = "insert into active_users(id,subject,initial_name,last_name,email,created_timestamp,updated_timestamp) values ('1','math','s','kl','ka@gmail.com', created_time, updated_time)";


		return "record inserted";


	}
}


