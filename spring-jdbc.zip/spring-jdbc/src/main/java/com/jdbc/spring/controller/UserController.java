package com.jdbc.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jdbc.spring.repo.UserRepository;

@RestController
@RequestMapping(path="sys_config")
public class UserController {

	
	@Autowired
	UserRepository userRepository;
	
	
	@RequestMapping(path = "/test")
	public String test() {
		
		return userRepository.test();
	}
	
	@RequestMapping(path = "/insert")
	public String insert() {
		
		return userRepository.insertRecord();
	}
	
}
